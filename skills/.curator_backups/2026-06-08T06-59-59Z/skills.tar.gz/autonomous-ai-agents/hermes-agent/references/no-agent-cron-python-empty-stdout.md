# no-agent cron Python script returns empty stdout under gateway

Session lesson: a `no_agent=true` cron job can run successfully but be marked `silent (empty output)` even when the target Python script prints normally from an interactive shell. In the observed case, Hermes cron logs showed repeated:

```text
Job '<job_id>' (no_agent): empty stdout — silent run
Job '<job_id>': agent returned [SILENT] — skipping delivery
```

Manual checks showed:

- `python <script>.py` from the shell produced the expected report.
- `cron.scheduler._run_job_script('<script>.py')` from an interactive shell produced non-empty output.
- The long-running gateway cron process still captured empty stdout for the same `.py` script.

Likely cause: the gateway process's `sys.executable` / inherited Python environment differed from the interactive PATH Python used in manual tests. Since `_run_job_script()` runs `.py` scripts with `sys.executable`, the scheduled process and the shell can disagree even when the file path is identical.

## Durable workaround

For deterministic report/watchdog jobs where the script must always print a user-facing report, wrap the Python script in a tiny `.sh` script and configure cron to run the wrapper. `.sh` scripts are executed with bash, so the wrapper can deliberately choose the known-good PATH Python.

Example wrapper under `~/.hermes/scripts/a_stock_paper_trader.sh`:

```bash
#!/usr/bin/env bash
set -euo pipefail
cd /c/Users/jax/AppData/Local/hermes
python /c/Users/jax/AppData/Local/hermes/scripts/a_stock_paper_trader.py
```

Then update all affected no-agent jobs to `script="a_stock_paper_trader.sh"` while preserving the existing schedule/delivery/workdir.

## Verification sequence

1. Run the wrapper directly:

```bash
bash /c/Users/jax/AppData/Local/hermes/scripts/a_stock_paper_trader.sh | head -60
```

2. Verify Hermes cron's runner sees stdout:

```bash
python - <<'PY'
import os, sys
os.environ['HERMES_HOME']='C:/Users/jax/AppData/Local/hermes'
sys.path.insert(0, 'C:/Users/jax/AppData/Local/hermes/hermes-agent')
from cron.scheduler import _run_job_script
ok, out = _run_job_script('a_stock_paper_trader.sh')
print('OK=', ok, 'LEN=', len(out))
print(out[:1200])
PY
```

3. Trigger one affected cron job manually with `cronjob(action='run', job_id=...)`.
4. Wait for the tick, then inspect logs for delivery:

```bash
grep -i '<job_id>' /c/Users/jax/AppData/Local/hermes/logs/agent.log | tail -20
```

Expected success line:

```text
Job '<job_id>': delivered to weixin:<chat> via live adapter
```

## Pitfall

Do not stop after verifying the original `.py` script manually; that only proves the script works in the interactive shell. For no-agent cron, verify through `_run_job_script()` and a manual cron trigger, because delivery depends on the long-running gateway scheduler's environment and stdout capture semantics.
