---
name: hermes-agent
description: "Use when configuring, setting up, using, extending, or troubleshooting Hermes Agent itself. Start here, then use official docs as source of truth and load narrower Hermes skills when relevant."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes-agent, operations, configuration, troubleshooting, skills]
    related_skills: [hermes-agent-operations, hermes-agent-skill-authoring, debugging-hermes-tui-commands]
---

# Hermes Agent

## Overview

Use this as the general entry point for Hermes Agent questions: setup, configuration, profiles, providers, tools, skills, plugins, cron jobs, gateway, TUI, and troubleshooting.

The authoritative source is always the current documentation at `https://hermes-agent.nousresearch.com/docs`. If this skill and the docs disagree, follow the docs and patch this skill afterward.

## When to Use

- The user asks how to configure, install, operate, or troubleshoot Hermes Agent.
- A system or user instruction says to load `hermes-agent` before working on Hermes itself.
- You need to choose a narrower Hermes workflow skill.

## Routing

- Use the operations workflow below for backups, restores, migrations, profiles, gateway-safe recovery, `~/.hermes`, cron verification, or live installation repair.
- Load `hermes-agent-skill-authoring` for creating or editing Hermes skills and `SKILL.md` files.
- Load `debugging-hermes-tui-commands` for TUI slash commands, gateway interactions, and UI command debugging.
- Use the official docs for current CLI commands, config schema, setup flows, provider/tool configuration, and feature behavior.

## Operations: Backup, Restore, Migration, and Repair

Use this section when the user asks to restore, back up, migrate, repair, or verify a Hermes Agent installation, especially anything involving `~/.hermes`, profiles, gateway state, or Git-backed backup state.

### Core Principles

1. Treat `~/.hermes` as the primary state directory for profiles, memories, skills, sessions, cron jobs, pairing data, logs, and local config.
2. Never overwrite an existing `~/.hermes` without first making a timestamped local backup.
3. Verify live prerequisites before acting: `hermes version`, `hermes profile list`, `git`, and SSH/auth access for remote backups.
4. Keep credentials local and private: `config.yaml`, `.env`, and `auth.json` may be intentionally excluded from Git backups and may need to be restored from a local backup.
5. Distinguish durable restore steps from environment-specific failures. Capture retry patterns and safety checks, not transient network or setup errors.

### Git-Backed Artifact Backup Workflow

When maintaining scheduled scripts that mirror selected Hermes artifacts to Git:

1. Keep paths portable: derive `HERMES_HOME` from `HERMES_HOME` or `Path.home() / ".hermes"`; avoid old host-specific paths.
2. Bound Git subprocesses with explicit timeouts so no-agent cron jobs fail clearly before the scheduler timeout.
3. Prefer SSH remotes for noninteractive cron pushes when SSH auth is configured; HTTPS requires token credentials.
4. If a local proxy is required, inject `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY` and lowercase variants for Git subprocesses from a script env var such as `HERMES_BACKUP_PROXY`.
5. Treat partial clone directories without `.git` as failed worktrees and recreate or archive them before retrying.
6. Push automated backups to a dedicated branch such as `hermes-artifacts-backup` when remote `main` has unrelated history; do not force-push unless explicitly requested.
7. Verify both manual script execution and a scheduler-triggered run; then confirm the remote backup branch with `git ls-remote`.

See `references/git-backed-artifact-backup.md` and `references/git-backup-cron-timeouts.md` for failure signatures and troubleshooting recipes.

### Git-Backed Restore Workflow

1. Inspect current state:
   - `command -v hermes && hermes version`
   - `test -e ~/.hermes && stat ~/.hermes`
   - `git ls-remote <repo>` or `ssh -T git@github.com` for GitHub SSH access.
2. Move the current directory aside:
   - `mv ~/.hermes ~/.hermes.backup.$(date +%F-%H%M%S)`
   - Save the backup path somewhere recoverable if the session may continue.
3. Clone the backup into place:
   - `git clone <repo> ~/.hermes`
   - If the clone is large or the connection is fragile, retry with `git clone --depth 1 <repo> ~/.hermes`.
4. If Hermes or the gateway recreates a skeleton `~/.hermes` between backup and clone, inspect it first, then move it aside as `~/.hermes.runtime-created.<timestamp>` before retrying the clone.
5. Restrict permissions after restore:
   - `chmod -R go-rwx ~/.hermes`
6. Verify the restored installation:
   - `hermes version`
   - `hermes profile list`
   - `git -C ~/.hermes status --short`
7. Verify restored scheduled jobs and portable paths:
   - Run `hermes cron list` and confirm expected jobs, schedules, scripts, delivery targets, and `workdir` values.
   - Inspect `~/.hermes/cron/jobs.json` when `hermes cron list` shows stale absolute paths from another machine; update job `workdir` values to the restored `~/.hermes` path instead of leaving jobs pointed at the old host.
   - For script-backed jobs, run the script once from the restored workdir and confirm it can find Git-backed data files. If a script hardcodes the old Hermes directory, prefer `Path(os.environ.get("HERMES_HOME", Path.home() / ".hermes"))` so future restores remain portable.

See `references/git-backed-home-restore.md` for restore notes and reporting pitfalls.

### Credentials, Config, and Gateway Pitfalls

Git backups of `~/.hermes` often omit secrets and machine-local config via `.gitignore`. After cloning, check whether `config.yaml`, `.env`, and `auth.json` exist. If missing and a pre-restore local backup exists, copy them back with preserved metadata:

```bash
for file in config.yaml .env auth.json; do
  if [ ! -e "$HOME/.hermes/$file" ] && [ -e "$backup/$file" ]; then
    cp -p "$backup/$file" "$HOME/.hermes/$file"
  fi
done
chmod -R go-rwx "$HOME/.hermes"
hermes profile list
```

After restoring local-only files, `git -C ~/.hermes status --short` may show expected dirty or untracked entries such as `config.yaml`, `.env`, `auth.json`, `SOUL.md`, `cron/jobs.json`, or `cron/output/...`. Report these as local/runtime state rather than treating them as restore failure, unless the user asked for a pristine Git working tree.

Only restart or start gateway services after file restore and profile verification are complete. Gateway restart changes live service state; if confirmation is required or denied, report that the restored files are in place but the gateway was not restarted.

## Working Rules

1. Prefer `hermes` CLI commands documented in the official docs over ad-hoc file edits.
2. Check live state before changing anything: version, profile, config, relevant files, and service status.
3. Back up important Hermes state before destructive operations, especially anything under `~/.hermes`.
4. Keep profile boundaries explicit: do not edit another profile's skills, plugins, cron jobs, or memories unless the user asks.
5. If you discover this skill is stale, patch it immediately.

## Verification Checklist

- [ ] Relevant narrower skill loaded when applicable.
- [ ] Official docs checked for current behavior when commands/config are involved.
- [ ] Live state verified with tools instead of assumptions.
- [ ] Changes tested or explicitly reported as unverified if blocked.
