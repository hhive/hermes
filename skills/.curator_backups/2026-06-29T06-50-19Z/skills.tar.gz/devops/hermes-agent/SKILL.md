---
name: hermes-agent
description: "Use when configuring, setting up, using, extending, or troubleshooting Hermes Agent itself. Start here, then use official docs as source of truth and load narrower Hermes skills when relevant."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes-agent, operations, configuration, troubleshooting, skills]
    related_skills: [hermes-agent-operations, hermes-agent-skill-authoring, debugging-hermes-tui-commands]
---

# Hermes Agent

## Overview

Use this as the general entry point for Hermes Agent questions: setup, configuration, profiles, providers, tools, skills, plugins, cron jobs, gateway, TUI, and troubleshooting.

The authoritative source is always the current documentation at `https://hermes-agent.nousresearch.com/docs`. If this skill and the docs disagree, follow the docs and patch this skill afterward.

## When to Use

- The user asks how to configure, install, operate, or troubleshoot Hermes Agent.
- A system or user instruction says to load `hermes-agent` before working on Hermes itself.
- You need to choose a narrower Hermes workflow skill.

## Routing

- Load `hermes-agent-operations` for backups, restores, migrations, profiles, gateway-safe recovery, `~/.hermes`, cron verification, or live installation repair.
- Load `hermes-agent-skill-authoring` for creating or editing Hermes skills and `SKILL.md` files.
- Load `debugging-hermes-tui-commands` for TUI slash commands, gateway interactions, and UI command debugging.
- Use the official docs for current CLI commands, config schema, setup flows, provider/tool configuration, and feature behavior.

## Working Rules

1. Prefer `hermes` CLI commands documented in the official docs over ad-hoc file edits.
2. Check live state before changing anything: version, profile, config, relevant files, and service status.
3. Back up important Hermes state before destructive operations, especially anything under `~/.hermes`.
4. Keep profile boundaries explicit: do not edit another profile's skills, plugins, cron jobs, or memories unless the user asks.
5. If you discover this skill is stale, patch it immediately.

## Verification Checklist

- [ ] Relevant narrower skill loaded when applicable.
- [ ] Official docs checked for current behavior when commands/config are involved.
- [ ] Live state verified with tools instead of assumptions.
- [ ] Changes tested or explicitly reported as unverified if blocked.
