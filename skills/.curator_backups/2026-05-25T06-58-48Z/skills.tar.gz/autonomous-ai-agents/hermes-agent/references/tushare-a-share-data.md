# Tushare for A-share paper-trading data

Use this when adding licensed/semistable A-share data to Hermes scheduled paper-trading or market-monitoring automations.

## Credential placement

- Store the token in Hermes home `.env` as `TUSHARE_TOKEN=<token>`.
- Never hardcode or echo the token in scripts, cron prompts, reports, logs, or skill files.
- In Python scripts, load from `os.getenv("TUSHARE_TOKEN")`; if the scheduler/runtime does not auto-load `.env`, parse the Hermes home `.env` explicitly or use the project's existing dotenv loader.

## Recommended role in the data stack

Tushare is best used for slower-changing/authoritative-ish datasets:

- `stock_basic` for A-share universe, names, industries, list dates.
- `daily` for EOD OHLCV and amount.
- `namechange` for ST/name-change history.
- Financial statements and other Pro datasets if the user's token tier permits.

For intraday prices, keep using a realtime quote layer such as Eastmoney primary + Sina/Tencent fallback/cross-check. Do not rely on Tushare alone for real-time reports.

## Permission probing pattern

Tushare token tiers vary by account. Before wiring an endpoint into a recurring job, run a small probe and cache the result in code/config comments:

```python
import os, tushare as ts

ts.set_token(os.environ["TUSHARE_TOKEN"])
pro = ts.pro_api()

for api, kwargs in {
    "stock_basic": {"exchange": "", "list_status": "L", "fields": "ts_code,symbol,name,industry,list_date"},
    "daily": {"ts_code": "000001.SZ", "start_date": "20260515", "end_date": "20260520"},
    "namechange": {"ts_code": "000001.SZ", "fields": "ts_code,name,start_date,end_date,change_reason"},
    "trade_cal": {"exchange": "", "start_date": "20260501", "end_date": "20260520", "fields": "cal_date,is_open,pretrade_date"},
}.items():
    try:
        df = getattr(pro, api)(**kwargs)
        print(api, "OK", len(df))
    except Exception as e:
        print(api, "NO_ACCESS_OR_ERROR", str(e)[:200])
```

If `trade_cal` is unavailable, avoid making it a hard dependency. Use a local exchange-calendar file, exchange/public calendar fallback, or infer market-open state from realtime quote availability and label that assumption in reports.

## Cron/reporting safeguards

- Keep Tushare failures non-fatal when a fallback source can answer the report.
- Include a short source-health line in reports, e.g. `数据源：Tushare日线 OK；东方财富实时 OK；新浪校验 OK`.
- Save raw source responses or normalized snapshots with timestamps so report conclusions are auditable.
