# Weixin QR login on Windows when terminal bash is unavailable

Use this when configuring Hermes Agent's Weixin/WeChat gateway and the normal `terminal()` path cannot start because Hermes cannot find Git Bash, or when you need to drive the QR login without relying on the interactive gateway wizard.

Key pattern:

1. Locate Git Bash with Python if needed. Common non-default install path seen on Windows:
   `D:\Program Files\Git\bin\bash.exe`
2. Persist the path for future Hermes sessions:
   `setx HERMES_GIT_BASH_PATH "D:\Program Files\Git\bin\bash.exe"`
3. Install Weixin QR/rendering dependencies into Hermes's own venv:
   `python -m pip install --upgrade aiohttp cryptography "qrcode[pil]"`
4. If the interactive `hermes gateway setup` path is blocked, run a small Python helper from the Hermes venv that imports:
   - `gateway.platforms.weixin.qr_login`
   - `hermes_cli.setup.save_env_value`
   - `hermes_cli.setup.get_env_value`
5. After `qr_login(get_hermes_home())` returns credentials, save at least:
   - `WEIXIN_ACCOUNT_ID`
   - `WEIXIN_TOKEN`
   - `WEIXIN_BASE_URL` when returned
   - `WEIXIN_CDN_BASE_URL=https://novac2c.cdn.weixin.qq.com/c2c`
6. Safe default access policy for unattended setup:
   - `WEIXIN_DM_POLICY=pairing`
   - `WEIXIN_ALLOW_ALL_USERS=false`
   - `WEIXIN_ALLOWED_USERS=`
   - `WEIXIN_GROUP_POLICY=disabled`
   - `WEIXIN_GROUP_ALLOWED_USERS=`
7. If `qr_login` returns `user_id`, set `WEIXIN_HOME_CHANNEL` to that ID.
8. The only unavoidable human step is scanning the QR URL/ASCII QR code with WeChat and confirming on the phone.

Do not save a negative rule like "terminal does not work". The durable lesson is the fix: set `HERMES_GIT_BASH_PATH` to the actual `bash.exe` and fall back to a Hermes-venv Python helper for QR login when the setup wizard cannot be driven through the shell tool.
