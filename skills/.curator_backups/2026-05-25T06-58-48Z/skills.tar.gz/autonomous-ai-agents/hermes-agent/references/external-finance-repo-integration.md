# External financial/trading repos integration notes

Use this reference when a user asks whether to connect GitHub trading/finance repositories into a Hermes scheduled automation.

## Decision pattern

1. Inspect the repo and identify the **smallest useful interface**:
   - public/read-only API endpoints
   - reusable scripts
   - methodology/templates
   - installable skill/plugin manifests
2. Avoid full platform installs unless they are necessary for the user's goal.
3. Prefer partial integration when the goal is a local automation:
   - call read-only APIs for context
   - extract research frameworks into local notes/templates
   - keep account state and execution logic local
4. Verify by running the deterministic script once and checking stdout/state.

## Example: AI-Trader + financial-services for A-share paper trading

- `HKUDS/AI-Trader` was useful mainly for read-only `https://ai4trade.ai/api/market-intel/*` context. No registration/token is needed for public market-intel endpoints. Good endpoints:
  - `/market-intel/overview`
  - `/market-intel/news?category=equities&limit=...`
  - `/market-intel/macro-signals`
  - `/market-intel/stocks/featured`
- Do not assume AI-Trader is an A-share execution engine; use it as market context unless the user explicitly wants platform registration, signal publishing, heartbeat polling, or copy trading.
- `anthropics/financial-services` is most useful as a research/workflow library, not a trading engine. Extract relevant frameworks such as:
  - equity-research `morning-note`
  - equity-research `idea-generation`
  - wealth-management `portfolio-rebalance`
- For A-share simulation, keep the trading script local and label all output as paper trading/simulation.

## Reporting language

When the user says “直接操作” or “如果有必要就接入”, act first: clone/inspect/integrate the necessary subset, test it, then report what was connected and what was intentionally not connected. Keep the reply concise and operational.
