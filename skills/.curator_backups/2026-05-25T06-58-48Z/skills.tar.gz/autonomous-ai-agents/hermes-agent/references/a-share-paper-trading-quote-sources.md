# A-share paper-trading quote-source pattern

Use this when maintaining deterministic Hermes cron scripts for A-share paper-trading/simulation reports.

## Quote source order

Prefer a multi-source quote layer instead of a single vendor endpoint:

1. **Eastmoney push2** as primary source
   - Endpoint: `https://push2.eastmoney.com/api/qt/ulist.np/get`
   - Useful params:
     - `fltt=2`, `invt=2`
     - `fields=f12,f13,f14,f2,f3,f4,f5,f6,f15,f16,f17,f18,f124`
     - `secids=1.512480,0.159941,...`
   - Market prefix: `1.` for Shanghai (`sh`), `0.` for Shenzhen (`sz`).
   - Useful fields: `f12` code, `f13` market, `f14` name, `f2` price, `f3` pct, `f5` volume, `f6` amount, `f15/f16/f17/f18` high/low/open/prev close, `f124` timestamp.

2. **Sina hq** as fallback / missing-code supplement
   - Endpoint: `https://hq.sinajs.cn/list=sh510300,sz159915,...`
   - Headers often needed: `User-Agent: Mozilla/5.0`, `Referer: https://finance.sina.com.cn/`.
   - Parse `var hq_str_<code>="...";` payloads. Early fields are name, prev close, open, current, high, low; date/time are commonly around fields 30/31.

3. **Tencent qt** as cross-check and second fallback
   - Endpoint: `https://qt.gtimg.cn/q=sh510300,sh510500,...`
   - Parse `v_<code>="...";` payloads split by `~`.
   - Common fields: `1` name, `2` raw code, `3` price, `4` prev close, `5` open, `30` timestamp, `32` percent change. Amount may be in ten-thousands depending on field; convert deliberately.

## Domain whitelist / no-browser mode

For this user's A-share paper-trading automation, keep market-data collection deterministic and non-browser-based:

- Use `requests` with browser-like headers (`User-Agent`, `Referer`, `Accept-Language`) rather than Selenium/Playwright/browser automation unless a source explicitly forces it.
- Enforce a hard allowlist before every outbound request. Current allowed domains: `api.tushare.pro`, `push2.eastmoney.com`, `hq.sinajs.cn`, `qt.gtimg.cn`, `www.cninfo.com.cn`, `static.cninfo.com.cn`.
- Explicitly block exchange/government/regulator domains for this workflow: `sse.com.cn`, `szse.cn`, `bse.cn`, `csrc.gov.cn`, and broad `gov.cn` hosts.
- Do not add research/news domains (for example third-party AI-trader APIs) unless the user explicitly authorizes them; keep external context to Tushare + CNINFO when this constraint is active.
- Print the access policy in reports, e.g. `数据策略：HTTP请求+浏览器请求头；域名白名单=东方财富/新浪/腾讯/巨潮/Tushare；未使用浏览器自动化；禁止访问交易所/政府网站`.

## CNINFO + Tushare support pattern

- Tushare token belongs in Hermes home `.env` as `TUSHARE_TOKEN=...`; scripts should load it from `os.environ` first and fall back to parsing `$HERMES_HOME/.env`/the known Hermes home `.env` because no-agent cron environments may not source the file.
- Tushare can be used for slow/stable reference data (`daily`, `stock_basic`, `namechange`) even if some endpoints such as `trade_cal` are unavailable for a low-permission token.
- CNINFO risk checks should use `www.cninfo.com.cn/new/hisAnnouncement/query` with browser-like headers and keyword scans for `立案/调查/处罚/退市/ST/风险/问询/监管`; do not substitute exchange announcement pages when the user requested no exchange/government access.

## Reporting

For this user's A-share paper-trading reports, keep user-facing output focused on investment content, not implementation details. Preferred sections:

1. 股市情况 — index snapshot and a compact quote-source health line.
2. 热点/趋势与未来方向 — deterministic trend/hotspot/outlook based on indices and the watchlist/sector groups; do not fetch extra news/research domains unless explicitly authorized.
3. 操作情况 — simulated buy/sell/hold.
4. 操作原因 — core market/risk-management rationale only; strip system/access-policy chatter such as Tushare/CNINFO implementation notes.
5. 资金情况 — cash, estimated market value, total assets, exposure.
6. 当前持仓 — concise position lines.

Avoid showing verbose system details in routine reports. Keep domain/access-policy details in code/logs unless the user asks to audit data access. A minimal data-health line is OK, e.g.:

`行情状态：东方财富主源12条；新浪补充1条；腾讯校验12条`

If the primary fails, do not fail the whole cron run when a fallback succeeds. Report the failure compactly:

`行情状态：新浪补充12条；腾讯校验12条；东方财富失败:ConnectionError`

## Cross-check rule

When both a primary/fallback quote and Tencent quote exist, compare prices. Flag only meaningful differences to avoid noisy reports; a threshold around `0.3%` is a practical default for ETF/stock quote sanity checks.

## Cron/script deployment pitfall

For no-agent cron jobs, verify the actual path the scheduler resolves. Some jobs configured with `script="scripts/name.py"` may resolve under `~/.hermes/scripts/scripts/name.py`. Keep the canonical script in `~/.hermes/scripts/name.py`, but if an existing job already depends on the nested path, sync a compatibility copy and verify with a manual cron run plus the latest `cron/output/<job_id>/*.md`.

## Verification checklist

- Run `python -m py_compile <script>` after edits.
- Run the script directly and confirm stdout contains quote-source status, portfolio state, and risk disclaimer.
- If cron-managed, trigger/list the job and confirm `last_status: ok` and the next run time.
- Avoid saving transient portfolio decisions as memory or skill content; keep only reusable automation patterns here.
