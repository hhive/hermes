# Weixin cron delivery rate-limit cooldown

Session lesson: cron-generated Weixin/WeChat reports can generate successfully but fail to arrive when iLink returns `rate limited` (`ret=-2`). Dense retry loops and immediate standalone fallback can worsen the limit window because the same account/channel receives another burst.

Reusable implementation pattern:

1. Keep generic transient send retry separate from rate-limit retry.
2. On iLink/Weixin rate limit (`ret == -2` or `errcode == -2`), wait a long cooldown before retrying. The proven default for user-facing scheduled reports is **180 seconds** and **one retry**.
3. Expose the cooldown as config/env rather than hardcoding:
   - `WEIXIN_SEND_RATE_LIMIT_RETRY_DELAY_SECONDS` default `180.0`
   - `WEIXIN_SEND_RATE_LIMIT_RETRIES` default `1`
4. Preserve short retry behavior for non-rate-limit transient send failures.
5. When cron delivery uses a live Weixin adapter, do **not** immediately fall back to standalone Weixin sending after live-adapter failure. The limit is account-wide, so fallback creates an extra send attempt during the same limit window. Let the adapter's cooldown retry path handle it.
6. Add a unit test by mocking `gateway.platforms.weixin._send_message` to return `{ret: RATE_LIMIT_ERRCODE}` then `{ret: 0}`, and mocking `asyncio.sleep`; assert the sleep is `180.0` and the send is attempted twice.

Files involved in Hermes source:

- `gateway/platforms/weixin.py` — adapter send/retry behavior.
- `cron/scheduler.py` — cron delivery live-adapter vs standalone fallback behavior.
- `tests/gateway/test_weixin.py` — chunk delivery and rate-limit retry tests.

Verification:

```bash
python -m py_compile gateway/platforms/weixin.py cron/scheduler.py tests/gateway/test_weixin.py
python -m pytest -q tests/gateway/test_weixin.py -q
```

If pytest is unavailable on a Windows end-user install, record that as setup state only; still run `py_compile`/`ast.parse` to catch syntax regressions.
