# Cron script path resolution for no-agent jobs

Session learning: a script-only cron job (`no_agent=True`) failed with:

```text
Script not found: C:\Users\jax\AppData\Local\hermes\scripts\scripts\a_stock_paper_trader.py
```

Context:
- Job was configured with `script="scripts/a_stock_paper_trader.py"` and `workdir="C:\Users\jax\AppData\Local\hermes"`.
- The cron runner treats script paths as relative to `~/.hermes/scripts/` (not relative to `workdir`).
- Therefore including a leading `scripts/` can resolve to `~/.hermes/scripts/scripts/<name>.py`.
- The `cronjob` tool may reject absolute script paths and says to place scripts under `~/.hermes/scripts/` and use a relative filename.

Preferred fix for future scheduled automations:
1. Place deterministic scripts under Hermes home scripts directory: `~/.hermes/scripts/<name>.py` (Windows profile may be `C:/Users/<user>/AppData/Local/hermes/scripts/<name>.py`).
2. Configure cron with `script="<name>.py"` when supported, and keep `workdir` as the project/Hermes home only if the script needs that cwd.
3. If an existing job is already expecting `scripts/<name>.py` and the scheduler keeps resolving under `~/.hermes/scripts/`, a compatibility shim/copy at `~/.hermes/scripts/scripts/<name>.py` can immediately unblock the job, but prefer normalizing the job config later.
4. Verify by triggering the job once and reading the latest `cron/output/<job_id>/*.md` or checking the cron job's `last_status` becomes `ok`.

Do not record the original missing-path failure as a permanent tool limitation; capture the path-resolution rule and the verification pattern.
